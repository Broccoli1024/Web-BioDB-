<?php
      header('Content-Type:text/html; charset=UTF-8');
      print "Hello World!<br>";
      print "こんにちは、<span style='color:#00ff00'>世界</span>！<br>";
?>
